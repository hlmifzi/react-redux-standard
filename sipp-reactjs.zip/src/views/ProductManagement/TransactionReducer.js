const INITIAL_STATE = {
    ManageAllProduct: {
        Action: '',
        icon:'nav-icon icon-layers',
        modul:'Manage All Product',
        dataSource: [],
        count: 0,
    },
    Entry: {
        Action: '',
        icon:'nav-icon icon-action-redo',
        modul:'Entry',
        dataSource: [
            {
                key: '0',
                No:1,
                Article: 'A0001',
                Tenant: 'Tenant 1',
                product_name: 'Sepatu',
                size: '42',
                color: 'merah',
                normal_stock: 12,
                ob_stock: 3,
                normal_price: '500,000',
                ob_price: '100,000',
            },
        ],
        count: 1,
    },
    Depreciation: {
        Action: '',
        icon:'nav-icon icon-arrow-down',
        modul:'Depreciation',
        dataSource: [
            {
                key: '0',
                No:1,
                Article: 'A0001',
                Tenant: 'Tenant 1',
                product_name: 'Sepatu',
                size: '42',
                color: 'merah',
                normal_stock: 12,
                ob_stock: 3,
                normal_price: '500,000',
                ob_price: '100,000',
            },
        ],
        count: 1,
    },
    Retur: {
        Action: '',
        icon:'nav-icon icon-action-undo',
        modul:'Retur',
        dataSource: [
            {
                key: '0',
                No:1,
                Article: 'A0001',
                Tenant: 'Tenant 1',
                product_name: 'Sepatu',
                size: '42',
                color: 'merah',
                normal_stock: 12,
                ob_stock: 3,
                normal_price: '500,000',
                ob_price: '100,000',
            },
        ],
        count: 1,
    },
    Selling: {
        Action: '',
        icon:'nav-icon icon-basket',
        modul:'Selling',
        dataSource: [
            {
                key: '0',
                No:1,
                Article: 'A0001',
                Tenant: 'Tenant 1',
                product_name: 'Sepatu',
                size: '42',
                color: 'merah',
                normal_stock: 12,
                ob_stock: 3,
                normal_price: '500,000',
                ob_price: '100,000',
            },
        ],
        count: 1,
    }
}

const TransactionReducer = (state = { ...INITIAL_STATE }, action) => {
    switch (action.type) {
        case "PRODUCTSLIST":
            return ({
                ...state,
                ManageAllProduct: {
                    ...state.ManageAllProduct,
                    dataSource: action.payload.dataSource,
                    count: action.payload.count
                }
            })
        case "PRODUCTSADD":
            return ({
                ...state,
                ManageAllProduct:{
                    ...state.ManageAllProduct,
                    Action:1
                }
            })
        default:
            return state;
    }
}

export default TransactionReducer