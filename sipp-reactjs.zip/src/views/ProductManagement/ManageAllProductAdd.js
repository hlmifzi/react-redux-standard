import React, { Component } from 'react';
import { Button, Card, CardBody, CardHeader, Col, Row, FormGroup, Label, CardFooter, Input } from 'reactstrap';
import { connect } from 'react-redux'
import { ProductSubmitAdd, ProductSubmitEdit, ProductSubmitDelete } from './TransactionAction'


class ManageAllProduct extends Component {
  state={
    tipe:'',
  }

  handleSave = row => {
    const newData = [...this.state.dataSource];
    const index = newData.findIndex(item => row.key === item.key);
    const item = newData[index];
    newData.splice(index, 1, {
      ...item,
      ...row,
    });
    this.setState({ dataSource: newData });
  };

  async componentWillMount() {
    try {
      
    } catch (e) {
      alert(e.massage)
    } 

    this.setState({tipe:this.props.match.params.tipe})
  }


  render() {
    let {tipe} = this.state
    let AddorEdit = tipe === 1 ? 'Add' : 'Edit'

    return (
      <div className="animated fadeIn">
        <Row>
          <Col xl={12}>
            <Card>
              <CardHeader>
                <i className={this.props.TransactionReducer.ManageAllProduct.icon}></i> {AddorEdit} Product
              </CardHeader>
              <CardBody>
                <Row>
                  <Col xs="4">
                    <FormGroup>
                      <Label htmlFor="name">Artikel</Label>
                      <Input type="text" id="name" placeholder="Input Your Artikel" required />
                    </FormGroup>
                  </Col>
                  <Col xs="4">
                    <FormGroup>
                      <Label htmlFor="ccmonth">Choose Tenant</Label>
                      <Input type="select" name="ccmonth" id="ccmonth">
                        <option value="1"> Tenant 1</option>
                        <option value="2"> Tenant 2</option>
                        <option value="3"> Tenant 3</option>
                        <option value="4"> Tenant 4</option>
                      </Input>
                    </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="8">
                    <FormGroup>
                      <Label htmlFor="name">Product Name</Label>
                      <Input type="text" id="name" placeholder="Input Product Name" required />
                    </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="3">
                    <FormGroup>
                      <Label htmlFor="name">Size</Label>
                      <Input type="text" placeholder="XS,S,M,L,XL,XXL" id="name"required />
                    </FormGroup>
                  </Col>
                  <Col xs="3">
                    <FormGroup>
                      <Label htmlFor="name">Color</Label>
                      <Input type="text"  placeholder="Putih" id="name" required />
                    </FormGroup>
                  </Col>
                  <Col xs="3">
                    <FormGroup>
                      <Label htmlFor="name">Normal Price</Label>
                      <Input type="number" id="name" required />
                    </FormGroup>
                  </Col>
                  <Col xs="3">
                    <FormGroup>
                      <Label htmlFor="name">OB Price</Label>
                      <Input type="number" id="name" required />
                    </FormGroup>
                  </Col>
                </Row>
              </CardBody>
              <CardFooter>
                <Button type="submit" size="sm" color="secondary" onClick={()=>(this.props.history.goBack())}><i className="fa fa-dot-circle-onav-icon icon-action-undo" ></i> Back</Button> &nbsp;
                <Button type="submit" size="sm" color="success"><i className="fa fa-dot-circle-o" ></i> Submit</Button> &nbsp;
              </CardFooter>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}


const mapStateToProps = state => ({
  TransactionReducer: state.TransactionReducer
})
const mapDispatchToProps = {
  ProductSubmitAdd,
  ProductSubmitEdit,
  ProductSubmitDelete
}
const connectRedux = connect(mapStateToProps, mapDispatchToProps)(ManageAllProduct)

export default connectRedux;