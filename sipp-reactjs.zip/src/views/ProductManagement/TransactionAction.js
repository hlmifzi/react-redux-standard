import ROOT_API from '../../MyServices/api/URLApi'

export const PRODUCTSLIST = 'PRODUCTSLIST'
export const PRODUCTSADD = 'PRODUCTSADD'
export const PRODUCTSEDIT = 'PRODUCTSEDIT'
export const PRODUCTSSUBMITADD = 'PRODUCTSSUBMITADD'
export const PRODUCTSSUBMITEDIT = 'PRODUCTSSUBMITEDIT'
export const PRODUCTSSUBMITDELETE = 'PRODUCTSSUBMITDELETE'

export const ENTRYADD = 'ENTRYADD'
export const DEPRECIATIONADD = 'DEPRECIATIONADD'
export const RETURADD = 'RETURADD'
export const SELLINGADD = 'SELLINGADD'




export const ProductGetList = payload => {
    return async dispatch => {

        const getData = await ROOT_API.post('barang',payload)
        let datas = getData.data

        let res = {}
        res['count'] = datas.count
        res['dataSource'] = []
        let no = 1
        datas.data.map((v) => {
            let BarangTypeArr = v.barang_types.map((v)=>({}))



            res['dataSource'].push({
                key: v.barang_id,
                No: no,
                Article: v.artikel,
                product_name: v.nama_barang,
                size: v.size,
                color: v.warna,
                // Tenant: BarangTypeArr
                // normal_stock: v.barang_types[0].stoks[0].jumlah,
                // ob_stock: v.barang_types[1].stoks[1].jumlah,
                // normal_price: v.barang_types[0].harga,
                // ob_price: v.barang_types[1].harga,
            })
            no += 1
            return res
        })
        
        console.log(res,'<<<<<<<< ');
        return dispatch({
            type: PRODUCTSLIST,
            payload: res
        })
    }
}

export const ProductAdd = payload => {
    return async dispatch => {
        return dispatch({
            type: PRODUCTSADD
        })
    }
}

export const ProductSubmitAdd = payload => {
    return async dispatch => {
        const insert = await ROOT_API.post('user', payload)

        const getData = await ROOT_API.get('user')

        let datas = getData.data

        let res = {}
        res['count'] = datas.count
        res['dataSource'] = []
        let no = 1
        datas.data.map((v) => {
            res['dataSource'].push({
                key: v.key,
                No: no,
                Role: v.role.role,
                Tenant: v.place.name,
                username: v.username,
            })
            no += 1
            return res
        })

        return dispatch({
            type: PRODUCTSEDIT,
            payload: insert.data.data,
            status: insert.data.meta.status
        })
    }
}

export const ProductEdit = payload => {
    return async dispatch => {
        return dispatch({
            type: PRODUCTSSUBMITADD,
            data: payload
        })
    }
}

export const ProductSubmitEdit = payload => {
    return async dispatch => {
        const insert = await ROOT_API.put('user', payload)

        const getData = await ROOT_API.get('user')

        let datas = getData.data

        let res = {}
        res['count'] = datas.count
        res['dataSource'] = []
        let no = 1
        datas.data.map((v) => {
            res['dataSource'].push({
                key: v.key,
                No: no,
                Role: v.place.name,
                Tenant: v.role.role,
                username: v.username,
            })
            no += 1

            return res
        })

        return dispatch({
            type: PRODUCTSSUBMITEDIT,
            payload: insert.data.data,
            status: insert.data.meta.status
        })
    }
}

export const ProductSubmitDelete = payload => {
    return async dispatch => {
        const insert = await ROOT_API.delete('user', { data: payload })
        const getData = await ROOT_API.get('user')

        let datas = getData.data

        let res = {}
        res['count'] = datas.count
        res['dataSource'] = []
        let no = 1
        datas.data.map((v) => {
            res['dataSource'].push({
                key: v.key,
                No: no,
                Role: v.place.name,
                Tenant: v.role.role,
                username: v.username,
            })
            no += 1

            return res
        })

        return dispatch({
            type: PRODUCTSSUBMITDELETE,
            payload: res,
            status: insert.data.meta.status
        })
    }
}


export const EntryAddAction = payload => {
    return async dispatch => {
        return dispatch({
            type: ENTRYADD
        })
    }
}

export const DepreciationAddAction = payload => {
    return async dispatch => {
        return dispatch({
            type: DEPRECIATIONADD
        })
    }
}

export const ReturAddAction = payload => {
    return async dispatch => {
        return dispatch({
            type: RETURADD
        })
    }
}

export const SellingAddAction = payload => {
    return async dispatch => {
        return dispatch({
            type: SELLINGADD
        })
    }
}


