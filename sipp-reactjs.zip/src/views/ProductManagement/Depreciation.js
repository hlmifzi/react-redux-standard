import React, { Component } from 'react';
import { Button, Card, CardBody, CardHeader, Col, Row, FormGroup, Label, CardFooter, Input } from 'reactstrap';
import { connect } from 'react-redux'
import { DepreciationAddAction } from './TransactionAction'


class ManageAllProduct extends Component {
  state = {
    tipe: '',
  }

  handleSave = row => {
    const newData = [...this.state.dataSource];
    const index = newData.findIndex(item => row.key === item.key);
    const item = newData[index];
    newData.splice(index, 1, {
      ...item,
      ...row,
    });
    this.setState({ dataSource: newData });
  };


  render() {
    const {
      icon,
      modul } = this.props.TransactionReducer.Depreciation;


    return (
      <div className="animated fadeIn">
        <Row>
          <Col xl={12}>
            <Card>
              <CardHeader>
                <i className={icon}></i> {modul}
              </CardHeader>
              <CardBody>
                <Row>
                  <Col xs="4">
                    <FormGroup>
                      <Label htmlFor="ccmonth">Choose Type Product</Label>
                      <Input type="select" name="ccmonth" id="ccmonth">
                        <option value="1"> Kemeja - Normal</option>
                        <option value="3"> Sepatu - Normal</option>
                      </Input>
                    </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="4">
                    <FormGroup>
                      <Label htmlFor="ccmonth">Place / Tenant From</Label>
                      <Input type="select" name="ccmonth" id="ccmonth">
                        <option value="1"> Gudang</option>
                        <option value="2"> Tenant 2</option>
                        <option value="3"> Tenant 3</option>
                        <option value="4"> Tenant 4</option>
                      </Input>
                    </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="3">
                    <FormGroup>
                      <Label htmlFor="name">Quantity</Label>
                      <Input type="number" id="name" required />
                    </FormGroup>
                  </Col>
                </Row>
              </CardBody>
              <CardFooter>
                <Button type="submit" size="sm" color="success"><i className="fa fa-dot-circle-o" ></i> Submit</Button> &nbsp;
              </CardFooter>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}


const mapStateToProps = state => ({
  TransactionReducer: state.TransactionReducer
})

const mapDispatchToProps = { DepreciationAddAction }
const connectRedux = connect(mapStateToProps, mapDispatchToProps)(ManageAllProduct)

export default connectRedux;