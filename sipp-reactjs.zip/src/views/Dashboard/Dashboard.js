import React, { Component } from 'react';
import Widget02 from '../Widgets/Widget02';
import {
  Col,
  Row,
} from 'reactstrap';

// Main Chart

//Random Numbers
function random(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

var elements = 27;
var data1 = [];
var data2 = [];
var data3 = [];

for (var i = 0; i <= elements; i++) {
  data1.push(random(50, 200));
  data2.push(random(80, 100));
  data3.push(65);
}

class Dashboard extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.onRadioBtnClick = this.onRadioBtnClick.bind(this);

    this.state = {
      dropdownOpen: false,
      radioSelected: 2,
    };
  }

  toggle() {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen,
    });
  }

  onRadioBtnClick(radioSelected) {
    this.setState({
      radioSelected: radioSelected,
    });
  }

  loading = () => <div className="spinner-grow text-primary animated fadeIn pt-1 d-flex justify-content-center"></div>

  render() {

    return (
      <div className="animated fadeIn">
        <Row>
          <Col xs="12" sm="6" lg="6">
            <Widget02 header="5" mainText="Total User" icon="fa fa-users" color="info" footer />
          </Col>
          <Col xs="12" sm="6" lg="6">
            <Widget02 header="20" mainText="Total Place" icon="fa fa-moon-o" color="warning" footer />
          </Col>
        </Row>  
       </div>
    );
  }
}

export default Dashboard;
