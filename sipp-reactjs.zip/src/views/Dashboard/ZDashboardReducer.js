const INITIAL_STATE = {
    Users: {
        Action: "",
        icon:'fa fa-users',
        modul:'Users',
    },
    Tenants: {
        Action: "",
        icon:'nav-icon icon-screen-desktop',
        modul:'Tenants Management',
    },
    dataSource: [],
    count: 1,
}

const MasterDataReducer = (state = { ...INITIAL_STATE }, action) => {
    switch (action.type) {
        case "LIST":
            return ({
                ...state,
                dataSource: action.payload
            })
        case "ADD":
            return ({
                ...state,
                Tenants:{
                    ...state.Tenants,
                    Action:1
                }
            })
        case "EDIT":
            return ({
                ...state,
                Tenants:{
                    ...state.Tenants,
                    Action:2
                }
            })
        default:
            return state;
    }
}

export default MasterDataReducer