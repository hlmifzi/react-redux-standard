import React, { Component } from 'react';
import Widget02 from '../Widgets/Widget02';
import Widget04 from '../Widgets/Widget04';
import {
  CardGroup,
  Col,
  Row,
} from 'reactstrap';

class Dashboard extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.onRadioBtnClick = this.onRadioBtnClick.bind(this);

    this.state = {
      dropdownOpen: false,
      radioSelected: 2,
    };
  }

  toggle() {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen,
    });
  }

  onRadioBtnClick(radioSelected) {
    this.setState({
      radioSelected: radioSelected,
    });
  }

  loading = () => <div className="spinner-grow text-primary animated fadeIn pt-1 d-flex justify-content-center"></div>

  render() {

    return (
      <div className="animated fadeIn">
        <Row>
          <Col xs="12" sm="6" lg="12">
            <Widget02 header="4" mainText="Type Product" icon="fa fa-bookmark-o" color="primary" />
          </Col>
        </Row>
        <Row>
          <Col sm="12" md="12">
            <Widget04 icon="fa fa-dropbox" color="info" header="67" value="25" invert>Stock All Product</Widget04>
          </Col>
        </Row>
        <CardGroup className="mb-4">
          <Widget04 icon="icon-basket-loaded" color="warning" header="60" value="25">Stock Normal Product</Widget04>
          <Widget04 icon="fa fa-shopping-bag" color="success" header="7" value="25">Stock OB Product</Widget04>
        </CardGroup>
      </div>
    );
  }
}

export default Dashboard;
