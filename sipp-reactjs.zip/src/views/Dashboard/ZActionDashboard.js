import ROOT_API from '../../MyServices/api/URLApi'

export const LIST = 'LIST'
export const ADD = 'ADD'
export const EDIT = 'EDIT'
export const UPDATE = 'UPDATE'
export const SUBMITADD = 'SUBMITADD'
export const SUBMITUPDATE = 'SUBMITUPDATE'


export const GetListAll = (param) => {
    return async dispatch => {
        return dispatch({
            type: LIST,
            payload: getData.data.data
        })
    }

}

export const AddAll = payload => {
    return async dispatch => {
        return dispatch({
            type: ADD,
            data: payload
        })
    }
}


export const EditAll = payload => {
    return async dispatch => {
        return dispatch({
            type: EDIT,
            data: payload
        })
    }
}


export const SubmitAddAll = payload => {
    return async dispatch => {
        return dispatch({
            type: EDIT,
            data: payload
        })
    }
}


export const SubmitEditAll = payload => {
    return async dispatch => {
        return dispatch({
            type: EDIT,
            data: payload
        })
    }
}
