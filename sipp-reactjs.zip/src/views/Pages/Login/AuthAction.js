import ROOT_API from '../../../MyServices/api/URLApi'

export const SIGN_IN = 'SIGN_IN'
export const SIGN_OUT = 'SIGN_OUT'


export const SignInAction = () => {
    return async dispatch => {
        // try {
            // const SignInCheck = await ROOT_API.get('/auth/login')

            // if (SignInCheck) {
                return dispatch({
                    type: SIGN_IN,
                })
        // } else {
        //         return dispatch({
        //             type: 'NOT_CORECTED',
        //             payload: SignInCheck
        //         })
        //     }
        // } catch (error) {

        // }
    }
}


export const SignOuthAction = () => {
    return async dispatch => {
        // try {
            // const SignInCheck = await ROOT_API.get('/auth/login')

            // if (SignInCheck) {
                return dispatch({
                    type: SIGN_OUT,
                })
        // } else {
        //         return dispatch({
        //             type: 'NOT_CORECTED',
        //             payload: SignInCheck
        //         })
        //     }
        // } catch (error) {

        // }
    }
}



// export const SignOutAction = () = async dispatch =>{
//     try {
//         const SignOut = await ROOT_API.get('/auth/logout')
//     } catch (error) {

//     }
// }