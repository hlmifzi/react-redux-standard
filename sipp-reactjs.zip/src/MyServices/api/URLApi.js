import axios from 'axios';

export default axios.create({
   baseURL: 'http://localhost:3001/',
   headers: {
      'authorization': 'Bearer $2b$10$/MhS37xM0vqZFdW6ANko9uQrjtZM7ZdsC6QR3Lkq4oTzqKHd.8IuG',
      'content-type': 'application/json'
   }
})
